from email.policy import default
import random
from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import datetime, timedelta

class expedition(models.Model):
    _name='lost.expedition'
    _description='EXPEDITION'

    island = fields.Many2one("lost.island", ondelete="cascade")
    survivor = fields.Many2one("lost.survivor", ondelete="cascade")
    start_time = fields.Datetime(default=lambda self: fields.Datetime.now())
    end_time = fields.Datetime(compute='_calculate_end_time')
    progress = fields.Float(compute='_get_progress')
    ended = fields.Boolean(default=False)
    

    @api.depends('start_time')
    def _calculate_end_time(self):
        for exp in self:
            data=fields.Datetime.from_string(exp.start_time)
            data=data+timedelta(hours=1)
            exp.end_time=fields.Datetime.to_string(data)

    @api.depends('start_time','island','survivor')
    def _get_progress(self):
        for t in self:
            time_remaining = fields.Datetime.context_timestamp(self, t.end_time) - fields.Datetime.context_timestamp( self, datetime.now())
            time_remaining = time_remaining.total_seconds() / 60 / 60
            t.progress = (1 - time_remaining / 1) * 100
            for y in t.survivor:
                y.busy=True
                if t.progress >= 100:
                    t.progress = 100
                    for s in t.island:
                        if (t.ended==False):
                            s.gold+=100
                            t.ended=True
                            y.busy=False

                else:
                    t.progress = t.progress

    @api.onchange('island')
    def _onchange_island(self):
        if self.island != False:
            survivor = self.island.survivors
            if survivor.busy==False:
                return {
                    'domain': {
                        'survivor': [('id', 'in', survivor.ids)]
                }
            }

class expedition_wizard(models.TransientModel):
    _name = 'lost.expedition_wizard'
    _description = 'lost.expedition_wizard'

    state = fields.Selection([
        ('1', "Nombre Isla / Superviviente"),
        ('2', "Confirmar Expedicion"),                                                                                                                       
      ], default='1')
    island = fields.Many2one('lost.island')
    survivor = fields.Many2one('lost.survivor')
    islas=fields.Many2one('lost.island',related='island',readonly=True)
    super = fields.Many2one('lost.survivor',related='survivor',readonly=True)


    def create_expedition(self):
        if(len(self.island) == 0):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'message': 'Selecciona una isla',
                    'type': 'danger',  # types: success,warning,danger,info
                    'sticky': False
                }
            }
        if( len(self.survivor) == 0):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'message': 'Selecciona un superiviente',
                    'type': 'danger',  # types: success,warning,danger,info
                    'sticky': False
                }
            }

        
        reserva = self.env['lost.expedition'].create({
            'island': self.island.id,
            'survivor': self.survivor.id
        })
        
        return {
            'name': 'Reserves',
            'view_type': 'form',
            'view_mode': 'form',   # Pot ser form, tree, kanban...
            'res_model': 'lost.expedition', # El model de destí
            'res_id': reserva.id,       # El id concret per obrir el form
        # 'view_id': self.ref('wizards.reserves_form') # Opcional si hi ha més d'una vista posible.
            'context': self._context,   # El context es pot ampliar per afegir opcions
            'type': 'ir.actions.act_window',
            'target': 'current',  # Si ho fem en current, canvia la finestra actual.
        }

    def next(self):
        

        if self.state == '1':
            self.state = '2'
            return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            }
        
        elif self.state == '2':
            return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            }

        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }

    @api.onchange('island')
    def _onchange_island(self):
        if self.island != False:
            survivor = self.island.survivors
            return {
                'domain': {
                    'survivor': [('id', 'in', survivor.ids)]
                }
            }