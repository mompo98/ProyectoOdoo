from distutils.command.build import build
from email.policy import default
import random
from odoo import models, fields, api

class building_type(models.Model):
    _name = 'lost.building_type'
    _description = 'Building types'

    name = fields.Char()
    productivity = fields.Integer()
    security = fields.Integer()
    supply = fields.Integer()
    cost=fields.Integer()
    time=fields.Integer()
    image = fields.Image(max_width=200, max_height=200)
    image_small = fields.Image(related='image', max_width=40, max_height=40,
                               string="image")
                               
class building(models.Model):
    _name='lost.building'
    _description='BUILDING'

    type = fields.Many2one('lost.building_type', ondelete='restrict')
    productivity = fields.Integer(compute='_putNum_')
    security = fields.Integer(compute='_putNum_')
    supply = fields.Integer(compute='_putNum_')
    cost =fields.Integer(compute='_putNum_')
    time =fields.Integer(compute='_putNum_')
    island = fields.Many2one('lost.island')
    finished=fields.Boolean(default=False)             

    @api.depends('type')
    def _putNum_(self):
        for c in self:
            if c.type !="":
                c.productivity = c.type.productivity
                c.security = c.type.security
                c.supply = c.type.supply
                c.cost =c.type.cost
                c.time =c.type.time
                
class building_wizard(models.TransientModel):
    _name = 'lost.building_wizard'
    _description = 'lost.building_wizard'

    state = fields.Selection([
        ('1', "Choose Building"),
        ('2', "Confirm"),                                                                                                                       
      ], default='1')
    type=fields.Many2one('lost.building_type')
    island = fields.Many2one('lost.island')
    islas=fields.Many2one('lost.island',related='island',readonly=True)


    def create_building(self):
        if(len(self.island) == 0):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'message': 'Selecciona una isla',
                    'type': 'danger',  # types: success,warning,danger,info
                    'sticky': False
                }
            }
        if( len(self.type) == 0):
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'message': 'Selecciona un edificio a construir',
                    'type': 'danger',  # types: success,warning,danger,info
                    'sticky': False
                }
            }

        
        reserva = self.env['lost.building'].create({
            'island': self.island.id,
            'type': self.type.id
        })
        
        return {
            'name': 'Reserves',
            'view_type': 'form',
            'view_mode': 'form',   # Pot ser form, tree, kanban...
            'res_model': 'lost.building', # El model de destí
            'res_id': reserva.id,       # El id concret per obrir el form
        # 'view_id': self.ref('wizards.reserves_form') # Opcional si hi ha més d'una vista posible.
            'context': self._context,   # El context es pot ampliar per afegir opcions
            'type': 'ir.actions.act_window',
            'target': 'current',  # Si ho fem en current, canvia la finestra actual.
        }

    def next(self):
        

        if self.state == '1':
            self.state = '2'
            return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            }
        
        elif self.state == '2':
            return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            }

        return {
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
        }