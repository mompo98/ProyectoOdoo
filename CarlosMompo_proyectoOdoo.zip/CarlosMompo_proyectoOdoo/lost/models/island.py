import random
from odoo import models, fields, api
from odoo.exceptions import UserError

class island(models.Model):
    _name='lost.island'
    _description = 'ISLAND'

    name = fields.Char()
    gold = fields.Integer()
    productivity = fields.Integer(compute= '_get_productivity')
    security = fields.Integer(compute= '_get_security')
    supply = fields.Integer(compute= '_get_supply')
    survivors = fields.One2many('lost.survivor','island')
    buildings = fields.One2many('lost.building','island')

    @api.depends('buildings')
    def _get_security(self):
        for c in self:
            total = 0
            for s in c.buildings:
                if s.security and self:
                    total =total + s.security
            c.security = total

    @api.depends('buildings')
    def _get_productivity(self):
        for c in self:
            total = 0
            for s in c.buildings:
                if s.productivity and self:
                    total =total + s.productivity
            c.productivity = total

    @api.depends('buildings')
    def _get_supply(self):
        for c in self:
            total = 0
            if total==0:
                total=500
            for s in c.buildings:
                if s.supply and self:
                    total += s.supply
            c.supply = total

    @api.depends('island')
    def generate_gold(self):
        if self.gold<self.supply:
            self.gold+=100
        else:
            raise UserError('No hay mas espacio en los almacenes')

    @api.depends('island')
    def empty_gold(self):
        self.gold=0

    @api.model
    def update_resources(self):
        totProd = self.search([('productivity','>',0)])
        for s in totProd:
            if s.gold<s.supply:
                s.gold+=s.productivity
            else:
                s.gold=s.supply


        
    player = fields.Many2one('res.partner')