import random
from email.policy import default
from odoo import models, fields, api

class player(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'
    _description = 'PLAYERS'

    is_player=fields.Boolean(default=False)
    island = fields.One2many('lost.island','player')

    

