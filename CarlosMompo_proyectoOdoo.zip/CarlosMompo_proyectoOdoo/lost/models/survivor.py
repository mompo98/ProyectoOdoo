from email.policy import default
from datetime import datetime
import random
from odoo import models, fields, api

class survivor(models.Model):
    _name='lost.survivor'
    _description = 'SURVIVORS'

    def _generate_job(self):
        opc = random.randint(1,100)
        if (opc<80): 
            job = ["Timber","Student","Police","Nursing_assistant","Mechanic","Scullion","Swimmer"]
            
            return random.choice(job)

        if (opc>=80 and opc<=90):
            job = ["Worker","Teacher","Liutenant","Nurse","Supervisor","Cook","Swimmer Coach"]
            
            return random.choice(job)

        if (opc>90):
            job = ["Architect","Engineer","Captain","Doctor","TOPMechanic","Chef","Professional swimmer"]
            
            return random.choice(job)

    def _generate_name(self):
        names=["Crystal Johnson","Andres Aguilar","Kristen Wells","Veronica Howard","Tonya Hall","Chase Marshall","Lisa Brown",
        "Michelle Hampton","Sandra Nguyen","John Jones","Alison Thomas","Hannah Dickerson","Bailey Odonnell","Kelly Oneill",
        "Angela Webster","Joshua Mason","Ronnie Chase","Katherine Walker","Victoria Brown","Antonio Adams","Alicia White",
        "Michael Horton","Morgan Morgan","Stacey Murphy","Tabitha Payne","Teresa Santana","Matthew Anderson","Adrian Cummings",
        "Michael Jacobs","Ann Curtis","David Nelson","Virginia Brown","Michael Rose","Keith Singh","Erin Graham","Billy Greer",
        "Daniel Haynes","Charles Hatfield","Dr. James Ellis ","Neil Rivera","Robert Phillips","Elizabeth Cox","Keith Walker",
        "Theresa Nicholson","Lauren Williams","Rhonda Dalton","Kathryn Smith","Jason Goodwin","Jason Chapman","Jonathan Prince"]
        return random.choice(names)

    def _generate_naci(self):
        inicio = datetime(1960, 1, 1)
        final =  datetime(2005, 12, 31)
        random_date = inicio + (final - inicio) * random.random()
        return random_date

    name = fields.Char(default=_generate_name)
    date_of_birth = fields.Date(default=_generate_naci)
    avatar = fields.Image(max_width=80, max__height=80)
    occupation =fields.Char(default=_generate_job)
    busy=fields.Boolean(default=False)
    island = fields.Many2one('lost.island')


    
    # @api.model
    # def update_resources(self):
    #     alive_survivors = self.search([('hungry','<',100)])
    #     for s in alive_survivors:
    #         if s.hungry>0:
    #             s.hungry-=1

    
            